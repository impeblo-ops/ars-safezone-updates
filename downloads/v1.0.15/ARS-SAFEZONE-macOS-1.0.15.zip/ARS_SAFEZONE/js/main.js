/* ============================================================================
   ARSSafezone - main.js
   ============================================================================ */

(function () {
    "use strict";

    var cs = new CSInterface();

    /* ----------------------------- State ----------------------------- */
    var orientation = "horizontal";
    var seqInfo = null;
    var busy = false;
    var lastSaveTimer = null;
    var activeTab = "social";

    var NOMINAL = { vertical: { w: 1080, h: 1920 }, horizontal: { w: 1920, h: 1080 } };

    var COLOR_ACTION = "#ffd24d";
    var COLOR_TITLE  = "#ff7a59";
    var COLOR_THIRDS = "#ffffff";

    var DEFAULTS = {
        rows: 3, cols: 3,
        marginsEnable: false,
        marginT: 5, marginB: 5, marginL: 5, marginR: 5, marginLock: false,
        gutterEnable: false, gutterCol: 2, gutterRow: 2, gutterLock: false,
        tMargin: false, tThirds: false, tCenter: false,
        tAction: false, tTitle: false, tDiagonals: false,
        includeCustom: false,
        platform: "none",
        opacity: 80, thickness: 1, color: "#94af76",
        placement: "whole", duration: 30
    };

    // Accent color per platform (used for the primary action icon and highlights).
    /* ----------------------------- DOM ----------------------------- */
    var $ = function (id) { return document.getElementById(id); };

    var els = {
        seqDot: $("seqDot"), seqName: $("seqName"), seqSpecs: $("seqSpecs"), refreshSeqBtn: $("refreshSeqBtn"),
        previewStage: $("previewStage"), previewFrame: $("previewFrame"),
        previewCanvas: $("previewCanvas"),

        replaceToggle: $("replaceToggle"),
        applyBtn: $("applyBtn"), removeBtn: $("removeBtn"), clearCacheBtn: $("clearCacheBtn"),
        status: $("status"),

        tabs: $("tabs"),
        rows: $("rows"), cols: $("cols"),
        marginT: $("marginT"), marginB: $("marginB"), marginL: $("marginL"), marginR: $("marginR"),
        marginLock: $("marginLock"), marginsEnable: $("marginsEnable"),
        gutterCol: $("gutterCol"), gutterRow: $("gutterRow"),
        gutterLock: $("gutterLock"), gutterEnable: $("gutterEnable"),
        marginCollapse: $("marginCollapse"), gutterCollapse: $("gutterCollapse"),
        tMargin: $("tMargin"), tThirds: $("tThirds"), tCenter: $("tCenter"),
        tAction: $("tAction"), tTitle: $("tTitle"), tDiagonals: $("tDiagonals"),
        opacity: $("opacity"), thickness: $("thickness"), lineColor: $("lineColor"),
        colorSwatch: $("colorSwatch"), swatchRow: $("swatchRow"), resetBtn: $("resetBtn"),

        includeCustom: $("includeCustom"),
        platform: $("platform"), platformGrid: $("platformGrid"),
        presetSelect: $("presetSelect"), savePresetBtn: $("savePresetBtn"), deletePresetBtn: $("deletePresetBtn"),

        activeList: $("activeList"), refreshListBtn: $("refreshListBtn"),

        modalOverlay: $("modalOverlay"), modalTitle: $("modalTitle"), modalLabel: $("modalLabel"),
        modalMessage: $("modalMessage"), modalField: $("modalField"),
        modalInput: $("modalInput"), modalOk: $("modalOk"), modalCancel: $("modalCancel")
    };

    /* ----------------------------- Helpers ----------------------------- */

    function jsxStr(s) { return JSON.stringify(String(s)); }

    function evalAsync(script) {
        return new Promise(function (resolve) {
            var done = false;
            var timer = setTimeout(function () { if (!done) { done=true; resolve("ERR|Premiere не ответил. Повторите действие."); } }, 15000);
            cs.evalScript(script, function (res) { if(done)return; done=true; clearTimeout(timer); resolve(res === undefined ? "" : String(res)); });
        });
    }

    function setStatus(msg, kind) {
        els.status.textContent = msg || "";
        els.status.className = "status" + (kind ? " " + kind : "");
    }

    function num(el, def, min, max) {
        var v = parseFloat(el.value);
        if (isNaN(v)) { v = def; }
        if (typeof min === "number" && v < min) { v = min; }
        if (typeof max === "number" && v > max) { v = max; }
        return v;
    }

    function normalizeHex(value) {
        var v = String(value || "").trim().toLowerCase();
        if (v.charAt(0) !== "#") { v = "#" + v; }
        if (/^#[0-9a-f]{3}$/.test(v)) { v = "#" + v[1] + v[1] + v[2] + v[2] + v[3] + v[3]; }
        if (/^#[0-9a-f]{6}$/.test(v)) { return v; }
        return null;
    }
    function getColor() { return normalizeHex(els.lineColor.value) || "#94af76"; }
    function applyColor(hex) { var n = normalizeHex(hex); if (n) { els.colorSwatch.style.background = n; } }

    function getOpts() {
        var mOn = els.marginsEnable.checked;
        var gOn = els.gutterEnable.checked;
        return {
            rows:      Math.round(num(els.rows, 3, 1, 64)),
            cols:      Math.round(num(els.cols, 3, 1, 64)),
            marginT:   mOn ? num(els.marginT, 0, 0, 49) : 0,
            marginB:   mOn ? num(els.marginB, 0, 0, 49) : 0,
            marginL:   mOn ? num(els.marginL, 0, 0, 49) : 0,
            marginR:   mOn ? num(els.marginR, 0, 0, 49) : 0,
            gutterEnable: gOn,
            gutterCol: gOn ? num(els.gutterCol, 0, 0, 20) : 0,
            gutterRow: gOn ? num(els.gutterRow, 0, 0, 20) : 0,
            showMargin: els.tMargin.checked,
            thirds:    els.tThirds.checked,
            center:    els.tCenter.checked,
            action:    els.tAction.checked,
            title:     els.tTitle.checked,
            diagonals: els.tDiagonals.checked,
            includeCustom: els.includeCustom.checked,
            platform:  els.platform.value,
            opacity:   num(els.opacity, 80, 1, 100) / 100,
            thickness: Math.round(num(els.thickness, 1, 1, 20)),
            color:     getColor()
        };
    }

    function currentDims() {
        if (seqInfo && seqInfo.width && seqInfo.height) { return { w: seqInfo.width, h: seqInfo.height }; }
        return NOMINAL[orientation];
    }

    // The "Include Custom Guide Builder" toggle only governs the Safe zones tab.
    // While the Custom Guide Builder tab is active, the custom guide is always shown.
    function effectiveOpts() {
        var o = getOpts();
        if (activeTab === "builder") { o.includeCustom = true; o.platform = "none"; }
        return o;
    }

    /* ----------------------------- Guide rendering ----------------------------- */

    function strokeLine(ctx, x1, y1, x2, y2) {
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    }
    function insetRect(cw, ch, frac) {
        var ix = cw * (1 - frac) / 2, iy = ch * (1 - frac) / 2;
        return { x: ix, y: iy, w: cw - ix * 2, h: ch - iy * 2 };
    }

    /* ---- Platform safe-zone overlays (user-supplied transparent PNGs) ---- */
    var PLATFORM_IMAGES = {
        tiktok: { img: null, loaded: false },
        reels:  { img: null, loaded: false },
        shorts: { img: null, loaded: false }
    };

    function loadOnePlatform(platform) {
        return new Promise(function (resolve) {
            var rec = PLATFORM_IMAGES[platform];
            if (!rec) { resolve(); return; }
            if (rec.loaded) { resolve(); return; }
            try {
                var path = cs.getSystemPath(SystemPath.EXTENSION) + "/assets/safezones/" + platform + ".png";
                var r = window.cep.fs.readFile(path, window.cep.encoding.Base64);
                if (!r || r.err !== 0 || !r.data) { resolve(); return; }
                var img = new Image();
                img.onload = function () { rec.img = img; rec.loaded = true; resolve(); };
                img.onerror = function () { resolve(); };
                img.src = "data:image/png;base64," + r.data;
            } catch (e) { resolve(); }
        });
    }

    function preloadPlatforms() {
        var keys = Object.keys(PLATFORM_IMAGES);
        for (var i = 0; i < keys.length; i++) {
            loadOnePlatform(keys[i]).then(function () { updatePreview(); });
        }
    }

    // Draw the platform overlay fit-centered inside the frame, preserving aspect ratio.
    function drawPlatformImage(ctx, cw, ch, platform) {
        var rec = PLATFORM_IMAGES[platform];
        if (!rec || !rec.loaded || !rec.img) { return; }
        var iw = rec.img.naturalWidth || rec.img.width;
        var ih = rec.img.naturalHeight || rec.img.height;
        if (!iw || !ih) { return; }
        var scale = Math.min(cw / iw, ch / ih);
        var dw = iw * scale, dh = ih * scale;
        var dx = (cw - dw) / 2, dy = (ch - dh) / 2;
        ctx.drawImage(rec.img, dx, dy, dw, dh);
    }


    function drawGuides(canvas, cw, ch, o) {
        canvas.width = cw; canvas.height = ch;
        var ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, cw, ch);

        var lw = Math.max(1, Math.round((ch / 720) * o.thickness));
        ctx.lineWidth = lw; ctx.lineCap = "butt";
        ctx.globalAlpha = o.opacity;

        if (o.includeCustom) {
        var ml = cw * o.marginL / 100, mr = cw * o.marginR / 100;
        var mt = ch * o.marginT / 100, mb = ch * o.marginB / 100;
        var gx = ml, gy = mt, gw = cw - ml - mr, gh = ch - mt - mb;
        if (gw < 1) { gw = 1; } if (gh < 1) { gh = 1; }

        ctx.strokeStyle = o.color;
        var i;
        var gcw = o.gutterEnable ? cw * o.gutterCol / 100 : 0;
        var gch = o.gutterEnable ? ch * o.gutterRow / 100 : 0;
        if (o.cols > 1) {
            for (i = 1; i < o.cols; i++) {
                var x = gx + gw * (i / o.cols);
                if (gcw > 0) {
                    strokeLine(ctx, x - gcw / 2, gy, x - gcw / 2, gy + gh);
                    strokeLine(ctx, x + gcw / 2, gy, x + gcw / 2, gy + gh);
                } else {
                    strokeLine(ctx, x, gy, x, gy + gh);
                }
            }
        }
        if (o.rows > 1) {
            for (i = 1; i < o.rows; i++) {
                var y = gy + gh * (i / o.rows);
                if (gch > 0) {
                    strokeLine(ctx, gx, y - gch / 2, gx + gw, y - gch / 2);
                    strokeLine(ctx, gx, y + gch / 2, gx + gw, y + gch / 2);
                } else {
                    strokeLine(ctx, gx, y, gx + gw, y);
                }
            }
        }

        if (o.showMargin) { ctx.strokeStyle = o.color; ctx.strokeRect(gx + lw / 2, gy + lw / 2, gw - lw, gh - lw); }

        if (o.thirds) {
            ctx.strokeStyle = COLOR_THIRDS; ctx.save();
            ctx.setLineDash([Math.max(6, lw * 4), Math.max(5, lw * 3)]);
            strokeLine(ctx, cw / 3, 0, cw / 3, ch); strokeLine(ctx, (cw / 3) * 2, 0, (cw / 3) * 2, ch);
            strokeLine(ctx, 0, ch / 3, cw, ch / 3); strokeLine(ctx, 0, (ch / 3) * 2, cw, (ch / 3) * 2);
            ctx.restore();
        }
        if (o.diagonals) {
            ctx.strokeStyle = o.color; ctx.save();
            ctx.setLineDash([Math.max(4, lw * 3), Math.max(4, lw * 3)]);
            strokeLine(ctx, 0, 0, cw, ch); strokeLine(ctx, cw, 0, 0, ch);
            ctx.restore();
        }
        if (o.center) {
            ctx.strokeStyle = o.color;
            strokeLine(ctx, cw / 2, 0, cw / 2, ch); strokeLine(ctx, 0, ch / 2, cw, ch / 2);
            var tick = Math.max(8, ch * 0.012); ctx.lineWidth = lw + 1;
            strokeLine(ctx, cw / 2 - tick, ch / 2, cw / 2 + tick, ch / 2);
            strokeLine(ctx, cw / 2, ch / 2 - tick, cw / 2, ch / 2 + tick);
            ctx.lineWidth = lw;
        }

        ctx.save();
        ctx.setLineDash([Math.max(8, lw * 5), Math.max(6, lw * 4)]);
        if (o.action) { var a = insetRect(cw, ch, 0.9); ctx.strokeStyle = COLOR_ACTION; ctx.strokeRect(a.x, a.y, a.w, a.h); }
        if (o.title)  { var t = insetRect(cw, ch, 0.8); ctx.strokeStyle = COLOR_TITLE;  ctx.strokeRect(t.x, t.y, t.w, t.h); }
        ctx.restore();
        }

        // Platform safe-zone overlays render exactly as provided (full opacity, no blend).
        ctx.globalAlpha = 1;
        if (o.platform && o.platform !== "none") { drawPlatformImage(ctx, cw, ch, o.platform); }
    }

    /* ----------------------------- Preview ----------------------------- */

    function updatePreview() {
        var dims = currentDims();
        var aspect = dims.w / dims.h;
        // Fill the stage at the sequence aspect ratio - identical sizing on every tab.
        var availW = Math.max(60, els.previewStage.clientWidth - 24);
        var availH = Math.max(60, els.previewStage.clientHeight - 24);
        var pw = availW, ph = Math.round(pw / aspect);
        if (ph > availH) { ph = availH; pw = Math.round(ph * aspect); }
        els.previewFrame.style.width = pw + "px";
        els.previewFrame.style.height = ph + "px";
        els.previewCanvas.style.width = pw + "px";
        els.previewCanvas.style.height = ph + "px";

        if (activeTab === "social" && window.ARSSafezoneSocial) {
            window.ARSSafezoneSocial.renderIntoFrame(els.previewCanvas, Math.max(2, pw * 2), Math.max(2, ph * 2));
            if (window.ARSSafezoneSocial.getIncludeCustom && window.ARSSafezoneSocial.getIncludeCustom()
                && window.ARSSafezoneSocial.getPlatform() !== "none") {
                compositeCustomGuide(els.previewCanvas);
            }
            return;
        }
        drawGuides(els.previewCanvas, pw * 2, ph * 2, effectiveOpts());
    }

    /* ----------------------------- Filesystem ----------------------------- */

    function ensureDir(path) {
        try { var st = window.cep.fs.stat(path); if (st.err !== 0) { window.cep.fs.makedir(path); } }
        catch (e) { try { window.cep.fs.makedir(path); } catch (e2) {} }
    }

    // Overlays are written to a per-user, always-writable folder. Writing into the
    // extension folder fails on Windows when it is installed under Program Files /
    // Common Files (read-only) -> cep.fs err 6 (ERR_CANT_WRITE).
    function overlaysDir() {
        var dir = userDir() + "/overlays";
        ensureDir(dir);
        return dir;
    }
    function savePngToDisk(base64, filename) {
        var outDir = overlaysDir();
        var full = outDir + "/" + filename;
        var r = window.cep.fs.writeFile(full, base64, window.cep.encoding.Base64);
        if (!r || r.err !== 0) {
            // Fallback to Documents if USER_DATA is somehow not writable.
            try {
                var docs = cs.getSystemPath(SystemPath.MY_DOCUMENTS);
                ensureDir(docs + "/ARS_SAFEZONE"); ensureDir(docs + "/ARS_SAFEZONE/overlays");
                var full2 = docs + "/ARS_SAFEZONE/overlays/" + filename;
                var r2 = window.cep.fs.writeFile(full2, base64, window.cep.encoding.Base64);
                if (r2 && r2.err === 0) { return full2; }
            } catch (e) {}
            throw new Error("Не удалось сохранить PNG (код " + (r ? r.err : "?") + ")");
        }
        return full;
    }

    function userDir() {
        var base = cs.getSystemPath(SystemPath.USER_DATA);
        var dir = base + "/ARS_SAFEZONE";
        ensureDir(dir);
        return dir;
    }
    function presetsPath() { return userDir() + "/presets.json"; }
    function lastPath() { return userDir() + "/last.json"; }

    function readJSON(path) {
        try { var r = window.cep.fs.readFile(path); if (r && r.err === 0 && r.data) { return JSON.parse(r.data); } }
        catch (e) {}
        return null;
    }
    function writeJSON(path, obj) {
        try { var w = window.cep.fs.writeFile(path, JSON.stringify(obj)); return (w && w.err === 0); }
        catch (e) { return false; }
    }

    /* ----------------------------- Settings model ----------------------------- */

    function collectSettings() {
        return {
            rows: num(els.rows, 3, 1, 64), cols: num(els.cols, 3, 1, 64),
            marginT: num(els.marginT, 5, 0, 49), marginB: num(els.marginB, 5, 0, 49),
            marginL: num(els.marginL, 5, 0, 49), marginR: num(els.marginR, 5, 0, 49),
            marginsEnable: els.marginsEnable.checked, marginLock: els.marginLock.checked,
            gutterCol: num(els.gutterCol, 2, 0, 20), gutterRow: num(els.gutterRow, 2, 0, 20),
            gutterEnable: els.gutterEnable.checked, gutterLock: els.gutterLock.checked,
            tMargin: els.tMargin.checked, tThirds: els.tThirds.checked, tCenter: els.tCenter.checked,
            tAction: els.tAction.checked, tTitle: els.tTitle.checked, tDiagonals: els.tDiagonals.checked,
            includeCustom: els.includeCustom.checked,
            platform: els.platform.value,
            opacity: num(els.opacity, 80, 1, 100), thickness: num(els.thickness, 1, 1, 20), color: getColor()
        };
    }

    function applySettings(s) {
        if (!s) { return; }
        function setVal(el, v) { if (v !== undefined && v !== null) { el.value = v; } }
        function setChk(el, v) { if (v !== undefined && v !== null) { el.checked = !!v; } }
        setVal(els.rows, s.rows); setVal(els.cols, s.cols);
        // Margins: enable state (infer from values for older presets), then values.
        var mEnable = (s.marginsEnable !== undefined) ? !!s.marginsEnable
            : (((s.marginT || 0) + (s.marginB || 0) + (s.marginL || 0) + (s.marginR || 0)) > 0);
        els.marginsEnable.checked = mEnable;
        if (mEnable) {
            setVal(els.marginT, s.marginT); setVal(els.marginB, s.marginB);
            setVal(els.marginL, s.marginL); setVal(els.marginR, s.marginR);
        } else {
            els.marginT.value = 0; els.marginB.value = 0; els.marginL.value = 0; els.marginR.value = 0;
        }
        setChk(els.marginLock, s.marginLock);
        syncMarginsUI();
        // Gutter: enable state (default off for older presets), then values.
        var gEnable = (s.gutterEnable !== undefined) ? !!s.gutterEnable : false;
        els.gutterEnable.checked = gEnable;
        if (gEnable) {
            setVal(els.gutterCol, s.gutterCol); setVal(els.gutterRow, s.gutterRow);
        } else {
            els.gutterCol.value = 0; els.gutterRow.value = 0;
        }
        setChk(els.gutterLock, s.gutterLock);
        syncGuttersUI();
        setChk(els.tMargin, s.tMargin); setChk(els.tThirds, s.tThirds); setChk(els.tCenter, s.tCenter);
        setChk(els.tAction, s.tAction); setChk(els.tTitle, s.tTitle); setChk(els.tDiagonals, s.tDiagonals);
        setChk(els.includeCustom, s.includeCustom);
        if (s.platform) { setPlatform(s.platform); } else { setPlatform("none"); }
        setVal(els.opacity, s.opacity); setVal(els.thickness, s.thickness);
        if (s.color) { els.lineColor.value = s.color; applyColor(s.color); }
        updatePreview();
    }

    function applyDefaults() {
        applySettings(DEFAULTS);
    }

    function scheduleSaveLast() {
        if (lastSaveTimer) { clearTimeout(lastSaveTimer); }
        lastSaveTimer = setTimeout(function () { writeJSON(lastPath(), collectSettings()); }, 600);
    }

    function liveChange() { updatePreview(); scheduleSaveLast(); }

    /* ----------------------------- Platform ----------------------------- */

    function setPlatform(value) {
        els.platform.value = value || "none";
        var cards = els.platformGrid.querySelectorAll(".preset-card");
        for (var i = 0; i < cards.length; i++) {
            cards[i].classList.toggle("active", cards[i].getAttribute("data-platform") === els.platform.value);
        }
    }

    /* ----------------------------- Modal prompt ----------------------------- */

    var modalResolve = null;
    var modalKind = "prompt";

    function resolveModal(ok) {
        els.modalOverlay.classList.remove("show");
        var r = modalResolve; modalResolve = null;
        if (!r) { return; }
        if (modalKind === "confirm") { r(ok); }
        else { r(ok ? els.modalInput.value : null); }
    }

    function promptModal(title, label, def, okText) {
        return new Promise(function (resolve) {
            modalResolve = resolve; modalKind = "prompt";
            els.modalTitle.textContent = title;
            els.modalMessage.style.display = "none";
            els.modalField.style.display = "";
            els.modalLabel.textContent = label;
            els.modalInput.value = def || "";
            els.modalOk.textContent = okText || "Сохранить";
            els.modalOk.className = "btn btn-primary";
            els.modalOverlay.classList.add("show");
            setTimeout(function () { els.modalInput.focus(); els.modalInput.select(); }, 30);
        });
    }

    function confirmModal(title, message, okText, danger) {
        return new Promise(function (resolve) {
            modalResolve = resolve; modalKind = "confirm";
            els.modalTitle.textContent = title;
            els.modalMessage.textContent = message;
            els.modalMessage.style.display = "";
            els.modalField.style.display = "none";
            els.modalOk.textContent = okText || "Подтвердить";
            els.modalOk.className = "btn " + (danger ? "btn-danger" : "btn-primary");
            els.modalOverlay.classList.add("show");
            setTimeout(function () { els.modalOk.focus(); }, 30);
        });
    }

    /* ----------------------------- Margin link ----------------------------- */

    function syncMarginsUI() {
        var on = els.marginsEnable.checked;
        els.marginT.disabled = !on; els.marginB.disabled = !on;
        els.marginL.disabled = !on; els.marginR.disabled = !on;
        els.marginLock.disabled = !on;
        els.marginCollapse.classList.toggle("open", on);
        els.marginLock.parentNode.classList.toggle("is-off", !on);
    }

    function handleMarginInput(src) {
        if (els.marginLock.checked) {
            var v = src.value;
            els.marginT.value = v; els.marginB.value = v; els.marginL.value = v; els.marginR.value = v;
        }
        liveChange();
    }

    function syncGuttersUI() {
        var on = els.gutterEnable.checked;
        els.gutterCol.disabled = !on; els.gutterRow.disabled = !on;
        els.gutterLock.disabled = !on;
        els.gutterCollapse.classList.toggle("open", on);
        els.gutterLock.parentNode.classList.toggle("is-off", !on);
    }

    function handleGutterInput(src) {
        if (els.gutterLock.checked) {
            var v = src.value;
            els.gutterCol.value = v; els.gutterRow.value = v;
        }
        liveChange();
    }

    /* ----------------------------- Presets list ----------------------------- */

    function readPresets() { return readJSON(presetsPath()) || {}; }

    function refreshPresetSelect(selectName) {
        var presets = readPresets();
        var names = [];
        for (var k in presets) { if (presets.hasOwnProperty(k)) { names.push(k); } }
        names.sort();
        els.presetSelect.innerHTML = "";
        var ph = document.createElement("option");
        ph.value = ""; ph.textContent = "Не выбран";
        els.presetSelect.appendChild(ph);
        for (var i = 0; i < names.length; i++) {
            var o = document.createElement("option");
            o.value = names[i]; o.textContent = names[i];
            els.presetSelect.appendChild(o);
        }
        if (selectName) { els.presetSelect.value = selectName; }
    }

    function savePreset() {
        promptModal("Сохранить пресет", "Название пресета", "", "Сохранить").then(function (name) {
            if (name === null) { return; }
            name = String(name).trim();
            if (!name) { setStatus("Введите название пресета.", "err"); return; }
            var presets = readPresets();
            presets[name] = collectSettings();
            if (writeJSON(presetsPath(), presets)) {
                refreshPresetSelect(name);
                setStatus("Пресет «" + name + "» сохранён.", "ok");
            } else {
                setStatus("Не удалось сохранить пресет.", "err");
            }
        });
    }

    function loadPreset() {
        var name = els.presetSelect.value;
        if (!name) { return; }
        var presets = readPresets();
        if (presets[name]) {
            applySettings(presets[name]);
            scheduleSaveLast();
            setStatus("Загружен пресет «" + name + "».", "ok");
        }
    }

    function deletePreset() {
        var name = els.presetSelect.value;
        if (!name) { setStatus("Выберите пресет для удаления.", "err"); return; }
        var presets = readPresets();
        if (presets[name]) {
            delete presets[name];
            writeJSON(presetsPath(), presets);
            refreshPresetSelect();
            setStatus("Preset \u201C" + name + "» удалён.", "ok");
        }
    }

    /* ----------------------------- Sequence ----------------------------- */

    function applySeqState(name, specs, dotClass) {
        els.seqName.textContent = name || "";
        els.seqSpecs.textContent = specs || "";
        els.seqSpecs.style.display = specs ? "" : "none";
        els.seqDot.className = "seq-dot" + (dotClass ? " " + dotClass : "");
    }

    function refreshSequence() {
        return evalAsync("getSequenceInfo()").then(function (res) {
            var parts = res.split("|");
            if (parts[0] !== "OK") {
                seqInfo = null; applySeqState(parts[1] || "Нет активной секвенции", "", "warn"); updatePreview(); return;
            }
            seqInfo = {
                width: parseInt(parts[1], 10), height: parseInt(parts[2], 10),
                fps: parseFloat(parts[3]), ticks: parseInt(parts[4], 10), name: parts[5] || "Секвенция"
            };
            orientation = (seqInfo.width < seqInfo.height) ? "vertical" : "horizontal";
            var specs = seqInfo.width + "\u00D7" + seqInfo.height + " \u00B7 " +
                (Math.round(seqInfo.fps * 100) / 100) + " fps \u00B7 " +
                (function(){var a=seqInfo.width,b=seqInfo.height;while(b){var t=b;b=a%b;a=t;}return (seqInfo.width/a)+":"+(seqInfo.height/a);}());
            applySeqState(seqInfo.name, specs, "ok");
            updatePreview();
        });
    }

    /* ----------------------------- Apply / Remove / Clear ----------------------------- */

    function generateAndApply() {
        if (busy) { return; }
        refreshSequence().then(function () {
            if (!seqInfo) { setStatus("Сначала откройте секвенцию на таймлайне.", "err"); return; }

            // -------- Social UI overlay (Instagram / Shorts / TikTok) --------
            if (activeTab === "social" && window.ARSSafezoneSocial) {
                if (window.ARSSafezoneSocial.getPlatform() === "none") {
                    setStatus("Сначала выберите соцсеть.", "err");
                    return;
                }
                busy = true; els.applyBtn.disabled = true; setStatus("Создаю наложение…", "busy");
                window.ARSSafezoneSocial.whenReady(function () {
                    try {
                        var sdims = currentDims();
                        // Render at the sequence's own dimensions: the 9:16 overlay is
                        // centered and stretched to the full sequence height, so it works
                        // on 9:16, 16:9, 1:1, 4:5 - any aspect ratio.
                        var scv = document.createElement("canvas");
                        var r = window.ARSSafezoneSocial.renderIntoFrame(scv, sdims.w, sdims.h);
                        if (window.ARSSafezoneSocial.getIncludeCustom && window.ARSSafezoneSocial.getIncludeCustom()) {
                            compositeCustomGuide(scv);
                        }
                        var b64 = scv.toDataURL("image/png").replace(/^data:image\/png;base64,/, "");
                        var plat = window.ARSSafezoneSocial.getOverlayKey();
                        var sfname = "ARS_SAFEZONE_social_" + plat + "_" + r.w + "x" + r.h + "_" + Date.now() + ".png";
                        var sPath = savePngToDisk(b64, sfname);
                        setStatus("Добавляю в Premiere…", "busy");
                        var sReplace = els.replaceToggle.checked ? "true" : "false";
                        var sScript = "applyOverlay(" + jsxStr(sPath) + ", " + jsxStr(sReplace) + ", " + jsxStr("whole") + ", 0)";
                        evalAsync(sScript).then(function (res) {
                            var sp = res.split("|");
                            if (sp[0] === "OK") {
                                setStatus("Добавлено на V" + sp[1] + " \u00B7 " + fmtTime(sp[2]) + "\u2013" + fmtTime(sp[3]) + ".", "ok");
                                refreshActiveList();
                            } else { setStatus(sp[1] || "Не удалось применить наложение.", "err"); }
                            busy = false; els.applyBtn.disabled = false;
                        });
                    } catch (e) {
                        setStatus("Ошибка: " + e.message, "err"); busy = false; els.applyBtn.disabled = false;
                    }
                });
                return;
            }

            var opts = effectiveOpts();
            if (!opts.includeCustom && (!opts.platform || opts.platform === "none")) {
                setStatus("Выберите соцсеть или вкладку «Направляющие».", "err");
                return;
            }
            busy = true; els.applyBtn.disabled = true; setStatus("Создаю направляющие…", "busy");
            var ready = (opts.platform && opts.platform !== "none") ? loadOnePlatform(opts.platform) : Promise.resolve();
            ready.then(function () {
            try {
                var dims = currentDims();
                var canvas = document.createElement("canvas");
                drawGuides(canvas, dims.w, dims.h, opts);
                var base64 = canvas.toDataURL("image/png").replace(/^data:image\/png;base64,/, "");
                var fname = "ARS_SAFEZONE_" + orientation + "_" + dims.w + "x" + dims.h + "_" + Date.now() + ".png";
                var fullPath = savePngToDisk(base64, fname);

                setStatus("Добавляю в Premiere…", "busy");
                var replace = els.replaceToggle.checked ? "true" : "false";
                var placement = "whole";
                var dur = 0;
                var script = "applyOverlay(" + jsxStr(fullPath) + ", " + jsxStr(replace) + ", " +
                    jsxStr(placement) + ", " + dur + ")";

                evalAsync(script).then(function (res) {
                    var p = res.split("|");
                    if (p[0] === "OK") {
                        setStatus("Добавлено на V" + p[1] + " \u00B7 " + fmtTime(p[2]) + "\u2013" + fmtTime(p[3]) + ".", "ok");
                        refreshActiveList();
                        writeJSON(lastPath(), collectSettings());
                    } else {
                        setStatus(p[1] || "Не удалось применить наложение.", "err");
                    }
                    busy = false; els.applyBtn.disabled = false;
                });
            } catch (e) {
                setStatus("Ошибка: " + e.message, "err"); busy = false; els.applyBtn.disabled = false;
            }
            });
        });
    }

    function removeOverlay() {
        if (busy) { return; }
        setStatus("Убираю наложения…", "busy");
        evalAsync("removeOverlays()").then(function (res) {
            var p = res.split("|");
            setStatus(p[0] === "OK" ? (p[1] + " наложений убрано.") : (p[1] || "Нет наложений для удаления."), p[0] === "OK" ? "ok" : "err");
            refreshActiveList();
        });
    }

    function setOverlayOpacityLive(pct) {
        evalAsync("setOverlayOpacity(" + pct + ")").then(function (res) {
            var p = res.split("|");
            setStatus(p[0] === "OK" ? ("Непрозрачность: " + pct + "%.") : (p[1] || "Не удалось изменить непрозрачность."), p[0] === "OK" ? "ok" : "err");
        });
    }

    function clearCache() {
        confirmModal(
            "Очистить файлы наложений",
            "This deletes every generated overlay PNG in /generated/overlays/, removes the \u201CARSSafezone Guides\u201D bin from the project, and removes any ARSSafezone guide currently on the timeline.",
            "Очистить", true
        ).then(function (ok) {
            if (!ok) { return; }
            evalAsync("deleteARSSafezoneBin()").then(function (binRes) {
                var bp = binRes.split("|");
                var binsRemoved = (bp[0] === "OK") ? (parseInt(bp[1], 10) || 0) : 0;
                var deleted = 0, failed = 0;
                try {
                    var outDir = userDir() + "/overlays";
                    var listed = window.cep.fs.readdir(outDir);
                    if (listed && listed.err === 0 && listed.data) {
                        var files = listed.data;
                        for (var i = 0; i < files.length; i++) {
                            var f = files[i];
                            if (f === "." || f === ".." || f === ".keep") { continue; }
                            if (!/\.png$/i.test(f)) { continue; }
                            var del = window.cep.fs.deleteFile(outDir + "/" + f);
                            if (del && del.err === 0) { deleted++; } else { failed++; }
                        }
                    }
                } catch (e) {
                    setStatus("Bin cleared, but file delete failed: " + e.message, "err"); refreshActiveList(); return;
                }
                var msg = "Cache cleared \u2014 " + deleted + " PNG(s)";
                if (binsRemoved > 0) { msg += ", project bin removed"; }
                if (failed > 0) { msg += " (" + failed + " file(s) could not be deleted)"; }
                setStatus(msg + ".", failed > 0 ? "err" : "ok");
                refreshActiveList();
            });
        });
    }

    /* ----------------------------- Active guides list ----------------------------- */

    function refreshActiveList() {
        evalAsync("listOverlays()").then(function (res) {
            var parts = res.split("|");
            els.activeList.innerHTML = "";
            if (parts[0] !== "OK" || !parts[1]) {
                var empty = document.createElement("div");
                empty.className = "empty-state"; empty.textContent = "На таймлайне пока нет наложений.";
                els.activeList.appendChild(empty); syncGutter(); return;
            }
            var items = parts[1].split(";;");
            for (var k = 0; k < items.length; k++) {
                var f = items[k].split("::");
                els.activeList.appendChild(buildGuideItem(f[0], f[1], f[2], f[3]));
            }
            syncGutter();
        });
    }

    function buildGuideItem(name, track, startSec, endSec) {
        var wrap = document.createElement("div"); wrap.className = "guide-item";
        var top = document.createElement("div"); top.className = "guide-item-top";
        var nm = document.createElement("span"); nm.className = "guide-item-name"; nm.textContent = name || "ARS SAFEZONE";
        var meta = document.createElement("span"); meta.className = "guide-item-meta";
        meta.textContent = (track || "V?") + " \u00B7 " + fmtTime(startSec) + "\u2013" + fmtTime(endSec);
        top.appendChild(nm); top.appendChild(meta);

        var opRow = document.createElement("div"); opRow.className = "guide-item-op";
        var opLabel = document.createElement("span"); opLabel.textContent = "Непрозрачность";
        var opSlider = document.createElement("input");
        opSlider.type = "range"; opSlider.min = "0"; opSlider.max = "100"; opSlider.step = "1"; opSlider.value = "100";
        var opVal = document.createElement("span"); opVal.style.minWidth = "34px"; opVal.textContent = "100%";
        opSlider.addEventListener("input", function () { opVal.textContent = opSlider.value + "%"; });
        opSlider.addEventListener("change", function () { setOverlayOpacityLive(parseInt(opSlider.value, 10)); });
        opRow.appendChild(opLabel); opRow.appendChild(opSlider); opRow.appendChild(opVal);

        var btnRow = document.createElement("div"); btnRow.className = "guide-item-op";
        var replaceBtn = document.createElement("button"); replaceBtn.className = "mini-btn"; replaceBtn.textContent = "Заменить";
        replaceBtn.addEventListener("click", function () { els.replaceToggle.checked = true; generateAndApply(); });
        var rmBtn = document.createElement("button"); rmBtn.className = "mini-btn danger"; rmBtn.textContent = "Убрать";
        rmBtn.addEventListener("click", removeOverlay);
        btnRow.appendChild(replaceBtn); btnRow.appendChild(rmBtn);

        wrap.appendChild(top); wrap.appendChild(opRow); wrap.appendChild(btnRow);
        return wrap;
    }

    function fmtTime(sec) {
        var s = Math.max(0, Math.round(parseFloat(sec) || 0));
        var m = Math.floor(s / 60), r = s % 60;
        return (m < 10 ? "0" + m : m) + ":" + (r < 10 ? "0" + r : r);
    }

    /* ----------------------------- Wiring ----------------------------- */

    function clampField(el) {
        var min = el.hasAttribute("min") ? parseFloat(el.getAttribute("min")) : null;
        var max = el.hasAttribute("max") ? parseFloat(el.getAttribute("max")) : null;
        var v = parseFloat(el.value);
        if (isNaN(v)) { return; }
        if (min !== null && v < min) { el.value = min; }
        if (max !== null && v > max) { el.value = max; }
    }

    function wire() {
        // Tabs
        var tabBtns = els.tabs.querySelectorAll(".tab");
        for (var i = 0; i < tabBtns.length; i++) {
            tabBtns[i].addEventListener("click", function () {
                var name = this.getAttribute("data-tab");
                activeTab = name;
                var all = els.tabs.querySelectorAll(".tab");
                for (var a = 0; a < all.length; a++) { all[a].classList.toggle("active", all[a] === this); }
                document.getElementById("panel-builder").classList.toggle("active", name === "builder");
                document.getElementById("panel-presets").classList.toggle("active", name === "presets");
                document.getElementById("panel-social").classList.toggle("active", name === "social");
                updatePreview();
                setTimeout(syncGutter, 0);
            });
        }

        // Number fields (excluding margins, which support linking)
        var numberFields = [els.rows, els.cols, els.opacity, els.thickness];
        for (var n = 0; n < numberFields.length; n++) {
            numberFields[n].addEventListener("input", liveChange);
            numberFields[n].addEventListener("change", function () { clampField(this); liveChange(); });
        }

        // Margin fields with optional linking
        var marginFields = [els.marginT, els.marginB, els.marginL, els.marginR];
        for (var m = 0; m < marginFields.length; m++) {
            marginFields[m].addEventListener("input", function () { handleMarginInput(this); });
            marginFields[m].addEventListener("change", function () { clampField(this); handleMarginInput(this); });
        }
        els.marginLock.addEventListener("change", function () {
            if (els.marginLock.checked) {
                var v = els.marginT.value;
                els.marginB.value = v; els.marginL.value = v; els.marginR.value = v;
            }
            liveChange();
        });
        els.marginsEnable.addEventListener("change", function () {
            var v = els.marginsEnable.checked ? 5 : 0;
            els.marginT.value = v; els.marginB.value = v; els.marginL.value = v; els.marginR.value = v;
            syncMarginsUI();
            liveChange();
        });

        // Gutter fields with optional linking
        var gutterFields = [els.gutterCol, els.gutterRow];
        for (var g = 0; g < gutterFields.length; g++) {
            gutterFields[g].addEventListener("input", function () { handleGutterInput(this); });
            gutterFields[g].addEventListener("change", function () { clampField(this); handleGutterInput(this); });
        }
        els.gutterLock.addEventListener("change", function () {
            if (els.gutterLock.checked) { els.gutterRow.value = els.gutterCol.value; }
            liveChange();
        });
        els.gutterEnable.addEventListener("change", function () {
            var v = els.gutterEnable.checked ? 2 : 0;
            els.gutterCol.value = v; els.gutterRow.value = v;
            syncGuttersUI();
            liveChange();
        });

        // Color
        els.lineColor.addEventListener("input", function () { applyColor(els.lineColor.value); liveChange(); });
        els.lineColor.addEventListener("change", function () {
            var c = getColor(); els.lineColor.value = c; applyColor(c); liveChange();
        });
        var swatches = els.swatchRow.querySelectorAll(".swatch");
        for (var s = 0; s < swatches.length; s++) {
            swatches[s].addEventListener("click", function () {
                var c = this.getAttribute("data-color"); els.lineColor.value = c; applyColor(c); liveChange();
            });
        }

        // Toggles
        var toggles = [els.tMargin, els.tThirds, els.tCenter, els.tAction, els.tTitle, els.tDiagonals, els.includeCustom];
        for (var t = 0; t < toggles.length; t++) { toggles[t].addEventListener("change", liveChange); }

        // Platform cards
        var cards = els.platformGrid.querySelectorAll(".preset-card");
        for (var c2 = 0; c2 < cards.length; c2++) {
            cards[c2].addEventListener("click", function () { setPlatform(this.getAttribute("data-platform")); liveChange(); });
        }

        // Presets
        els.savePresetBtn.addEventListener("click", savePreset);
        els.deletePresetBtn.addEventListener("click", deletePreset);
        els.presetSelect.addEventListener("change", loadPreset);

        // Actions
        els.applyBtn.addEventListener("click", generateAndApply);
        els.removeBtn.addEventListener("click", removeOverlay);
        if (els.clearCacheBtn) { els.clearCacheBtn.addEventListener("click", clearCache); }
        els.resetBtn.addEventListener("click", function () { applyDefaults(); scheduleSaveLast(); setStatus("Исходные настройки восстановлены.", "ok"); });

        els.refreshSeqBtn.addEventListener("click", function () { setStatus("Обновляю данные секвенции…", "busy"); refreshSequence().then(function () { setStatus("", ""); }); });
        els.refreshListBtn.addEventListener("click", refreshActiveList);

        // Modal
        els.modalOk.addEventListener("click", function () { resolveModal(true); });
        els.modalCancel.addEventListener("click", function () { resolveModal(false); });
        els.modalOverlay.addEventListener("click", function (e) { if (e.target === els.modalOverlay) { resolveModal(false); } });
        document.addEventListener("keydown", function (e) {
            if (!els.modalOverlay.classList.contains("show")) { return; }
            if (e.key === "Enter") { e.preventDefault(); resolveModal(true); }
            else if (e.key === "Escape") { e.preventDefault(); resolveModal(false); }
        });

        window.addEventListener("resize", function () { updatePreview(); syncGutter(); });
        window.addEventListener("focus", function () { refreshSequence(); refreshActiveList(); });
    }

    /* ----------------------------- Init ----------------------------- */

    function compositeCustomGuide(canvas) {
        try {
            var o = getOpts();
            o.includeCustom = true;   // this is only called when the Platform checkbox is on
            o.platform = "none";      // draw the custom guide only, not a safe-zone image
            var tmp = document.createElement("canvas");
            tmp.width = canvas.width; tmp.height = canvas.height;
            drawGuides(tmp, tmp.width, tmp.height, o);
            canvas.getContext("2d").drawImage(tmp, 0, 0);
        } catch (e) { /* ignore */ }
    }

    function initSplitter() {
        var sp = $("colSplitter");
        var left = document.querySelector(".col-left");
        var cols = document.querySelector(".columns");
        if (!sp || !left || !cols) { return; }
        var dragging = false;
        function onMove(e) {
            if (!dragging) { return; }
            var rect = cols.getBoundingClientRect();
            var w = e.clientX - rect.left;
            var min = 170, max = rect.width - 300;
            if (max < min) { max = min; }
            if (w < min) { w = min; }
            if (w > max) { w = max; }
            left.style.flex = "0 0 " + w + "px";
            left.style.maxWidth = "none";
            updatePreview();
        }
        sp.addEventListener("mousedown", function (e) {
            dragging = true; sp.classList.add("dragging");
            document.body.style.cursor = "col-resize";
            document.body.style.userSelect = "none";
            e.preventDefault();
        });
        window.addEventListener("mousemove", onMove);
        window.addEventListener("mouseup", function () {
            if (!dragging) { return; }
            dragging = false; sp.classList.remove("dragging");
            document.body.style.cursor = ""; document.body.style.userSelect = "";
            updatePreview();
        });
    }

    function syncGutter() {
        var rs = $("rightScroll");
        if (!rs) { return; }
        var sbw = rs.offsetWidth - rs.clientWidth;   // real scrollbar width (0 when none)
        if (sbw < 0) { sbw = 0; }
        var tabs = document.querySelector(".tabs");
        var acts = document.querySelector(".right-actions");
        if (tabs) { tabs.style.marginRight = sbw + "px"; }
        if (acts) { acts.style.marginRight = sbw + "px"; }
    }

    function enhanceSelect(sel) {
        var wrap = sel.parentNode;
        if (!wrap || !wrap.classList || !wrap.classList.contains("cselect")) { return; }
        var btn = wrap.querySelector(".cselect-btn");
        var val = wrap.querySelector(".cselect-val");
        var list = wrap.querySelector(".cselect-list");
        function label() {
            var o = sel.options[sel.selectedIndex];
            return o ? o.textContent : (sel.value || "Не выбран");
        }
        function rebuild() {
            list.innerHTML = "";
            for (var i = 0; i < sel.options.length; i++) {
                (function (opt) {
                    var it = document.createElement("div");
                    it.className = "cselect-item" + (opt.value === sel.value ? " sel" : "");
                    it.textContent = opt.textContent;
                    it.addEventListener("click", function (e) {
                        e.stopPropagation();
                        sel.value = opt.value;
                        val.textContent = opt.textContent;
                        wrap.classList.remove("open");
                        sel.dispatchEvent(new Event("change"));
                        rebuild();
                    });
                    list.appendChild(it);
                })(sel.options[i]);
            }
            val.textContent = label();
        }
        btn.addEventListener("click", function (e) {
            e.stopPropagation();
            rebuild();
            wrap.classList.toggle("open");
        });
        document.addEventListener("click", function () { wrap.classList.remove("open"); });
        try {
            var obs = new MutationObserver(rebuild);
            obs.observe(sel, { childList: true, subtree: true });
        } catch (e) { /* ignore */ }
        rebuild();
    }

    function init() {
        wire();
        var last = readJSON(lastPath());
        if (last) { applySettings(last); } else { applyDefaults(); }
        els.includeCustom.checked = false;   // always start off
        preloadPlatforms();
        if (window.ARSSafezoneSocial) {
            window.ARSSafezoneSocial.init($("socialControls"), function () {
                if (activeTab === "social") { updatePreview(); }
                setTimeout(syncGutter, 0);
            });
        }
        initSplitter();
        enhanceSelect($("presetSelect"));
        updatePreview();
        syncGutter(); setTimeout(syncGutter, 60);
        refreshPresetSelect();
        refreshSequence();
        refreshActiveList();
    }

    if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", init); }
    else { init(); }
})();
