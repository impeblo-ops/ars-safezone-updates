#!/bin/bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$DIR/ARS_SAFEZONE"
PARENT="$HOME/Library/Application Support/Adobe/CEP/extensions"
TARGET="$PARENT/ARS_SAFEZONE"
DATA="$HOME/Library/Application Support/ARS_SAFEZONE"
echo 'ARS SAFEZONE 1.0.2 — установка'
echo 'Закройте Premiere Pro перед установкой.'
if pgrep -f '/Adobe Premiere Pro[^/]*/Adobe Premiere Pro.*Contents/MacOS/' >/dev/null 2>&1; then
  echo 'Premiere Pro открыт. Закройте программу и запустите установщик снова.'
  read -r -p 'Нажмите Enter для выхода…' || true
  exit 1
fi
if [[ ! -f "$SOURCE/CSXS/manifest.xml" ]] || ! grep -q 'com.ars.safezone.cep' "$SOURCE/CSXS/manifest.xml"; then
  echo 'Не найдена папка ARS_SAFEZONE рядом с установщиком. Распакуйте архив полностью.'
  read -r -p 'Нажмите Enter для выхода…' || true
  exit 1
fi
mkdir -p "$PARENT" "$DATA/installation-backups"
STAGE="$(mktemp -d "$PARENT/.ars-stage.XXXXXX")"
BACKUP="$DATA/installation-backups/$(date +%Y%m%d-%H%M%S)-$$"
OLD_MOVED=0
NEW_MOVED=0
rollback() {
  echo 'Установка не завершена. Восстанавливаю прежнюю версию.'
  if [[ "$NEW_MOVED" = 1 && -d "$TARGET" ]]; then mv "$TARGET" "$DATA/installation-backups/failed-$(date +%Y%m%d-%H%M%S)-$$"; fi
  if [[ "$OLD_MOVED" = 1 && ! -e "$TARGET" ]]; then mv "$BACKUP" "$TARGET"; fi
}
trap rollback ERR
cp -R "$SOURCE/." "$STAGE/"
if [[ -e "$TARGET" ]]; then
  if [[ ! -f "$TARGET/CSXS/manifest.xml" ]] || ! grep -q 'com.ars.safezone.cep' "$TARGET/CSXS/manifest.xml"; then
    echo 'Папка назначения занята другой панелью. Файлы не изменены.'; exit 1
  fi
  mv "$TARGET" "$BACKUP"; OLD_MOVED=1
fi
mv "$STAGE" "$TARGET"; NEW_MOVED=1
echo 'Включаю загрузку неподписанных панелей CEP для текущего пользователя.'
for V in 10 11 12 13; do defaults write "com.adobe.CSXS.$V" PlayerDebugMode 1; done
trap - ERR
echo 'Готово! Откройте Premiere → Окно → Расширения → ARS SAFEZONE.'
echo 'На английском: Window → Extensions → ARS SAFEZONE.'
echo 'Пресеты и созданные наложения сохранены.'
read -r -p 'Нажмите Enter для выхода…' || true
