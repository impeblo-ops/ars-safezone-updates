/**************************************************************************************************
 * ARSSafezone - hostscript.jsx
 * ExtendScript that runs inside Premiere Pro.
 *
 * All functions return a simple delimited string so the panel can parse results without
 * requiring a JSON engine inside ExtendScript.
 *   Success: "OK|...."
 *   Error:   "ERR|message"
 **************************************************************************************************/

#target premierepro

var ARS_SAFEZONE_PREFIX = "ARS_SAFEZONE_";
var ARS_SAFEZONE_BIN = "ARS SAFEZONE";
var TICKS_PER_SECOND = 254016000000;

/* -------------------------------------------------------------------------------------------- */
/* Public API                                                                                   */
/* -------------------------------------------------------------------------------------------- */

/**
 * Returns information about the active sequence.
 * Format: OK|width|height|fps|ticksPerFrame|name
 */
function getSequenceInfo() {
    try {
        if (!app.project) { return "ERR|Откройте проект"; }
        var seq = app.project.activeSequence;
        if (!seq) { return "ERR|Нет активной секвенции. Open a sequence in the timeline."; }

        var w = 1920, h = 1080, ticks = 0, fps = 0;

        // Preferred: read from sequence settings.
        try {
            var s = seq.getSettings();
            if (s && s.videoFrameWidth) { w = parseInt(s.videoFrameWidth, 10); }
            if (s && s.videoFrameHeight) { h = parseInt(s.videoFrameHeight, 10); }
        } catch (eSettings) {}

        // Frame rate from timebase (ticks per frame).
        try {
            ticks = parseInt(seq.timebase, 10);
            if (ticks > 0) { fps = TICKS_PER_SECOND / ticks; }
        } catch (eTb) {}

        if (!fps || fps <= 0) { fps = 25; }

        return "OK|" + w + "|" + h + "|" + _round2(fps) + "|" + ticks + "|" + _clean(seq.name);
    } catch (e) {
        return "ERR|" + e.toString();
    }
}

/**
 * Imports the PNG and places it on a fresh top video track.
 *   placement: "start" | "playhead" | "inout" | "whole"
 *   durationSeconds: used for "start" and "playhead" (and as fallback)
 * If replace == "true", existing ARSSafezone overlays are removed first.
 * Format: OK|trackIndex|startSec|endSec
 */
function applyOverlay(pngPath, replace, placement, durationSeconds) {
    try {
        if (!app.project) { return "ERR|Откройте проект"; }
        var seq = app.project.activeSequence;
        if (!seq) { return "ERR|Нет активной секвенции"; }

        var dur = parseFloat(durationSeconds);
        if (isNaN(dur) || dur <= 0) { dur = 5; }
        var doReplace = (String(replace) === "true");
        placement = String(placement || "start");

        var f = new File(pngPath);
        if (!f.exists) { return "ERR|Не найден файл PNG: " + pngPath; }

        var bin = _getARSSafezoneBin();
        app.project.importFiles([pngPath], true, bin, false);

        var fname = _baseName(pngPath);
        var item = _findProjectItemByName(app.project.rootItem, fname);
        if (!item) { return "ERR|Не удалось импортировать файл: " + fname; }

        // Resolve start / end based on the placement mode.
        var seqEnd = _sequenceEndSeconds(seq);
        var startSec = 0, endSec = 0;
        if (placement === "playhead") {
            try { startSec = seq.getPlayerPosition().seconds; } catch (eP) { startSec = 0; }
            endSec = startSec + dur;
        } else if (placement === "inout") {
            var inS = _inPointSeconds(seq);
            var outS = _outPointSeconds(seq);
            if (outS > inS) { startSec = inS; endSec = outS; }
            else { startSec = inS; endSec = inS + dur; }
        } else if (placement === "whole") {
            startSec = 0;
            endSec = (seqEnd > 0 ? seqEnd : dur);
        } else {
            startSec = 0;
            endSec = startSec + dur;
        }
        if ((placement === "whole" || placement === "inout") && seqEnd > 0 && endSec > seqEnd) {
            endSec = seqEnd;
        }
        if (endSec <= startSec) { endSec = startSec + dur; }

        // Decide which video track to use:
        //   - Replace + a guide already exists -> reuse the track it's on.
        //   - An empty track sits above all tracks -> use that track.
        //   - Otherwise -> add a new track on top.
        var existingTrackIndex = _findARSSafezoneTrackIndex(seq);
        var topIndex;
        if (doReplace && existingTrackIndex >= 0 && _trackOnlyHasARS(seq.videoTracks[existingTrackIndex])) {
            topIndex = existingTrackIndex;
        } else {
            topIndex = _resolveEmptyTopOrNewTrack(seq);
        }
        var track = seq.videoTracks[topIndex];
        if (!track) { return "ERR|Недоступна видеодорожка"; }
        try { if(track.isLocked()) return "ERR|Видеодорожка заблокирована. Снимите блокировку."; } catch(lockErr) {}

        if (doReplace) { _removeOverlayClips(seq); }

        try { track.overwriteClip(item, startSec); }
        catch (eOver) { track.insertClip(item, startSec); }

        var clip = track.clips[track.clips.numItems - 1];
        if (!clip) { return "ERR|Не удалось разместить наложение"; }

        var realStart = startSec;
        try { realStart = clip.start.seconds; } catch (eRS) {}
        var span = endSec - startSec;
        var endT = new Time();
        endT.seconds = realStart + span;
        try { clip.end = endT; } catch (eEnd) {}

        try { clip.name = ARS_SAFEZONE_PREFIX + "Наложение"; } catch (eN) {}

        return "OK|" + (topIndex + 1) + "|" + _round2(realStart) + "|" + _round2(realStart + span);
    } catch (e) {
        return "ERR|" + e.toString();
    }
}

/**
 * Removes every ARSSafezone overlay clip from the active sequence.
 * Format: OK|removedCount
 */
function removeOverlays() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) { return "ERR|Нет активной секвенции"; }
        var n = _removeOverlayClips(seq);
        return "OK|" + n;
    } catch (e) {
        return "ERR|" + e.toString();
    }
}

/**
 * Sets the Opacity (0..100) of every ARSSafezone overlay clip via its Opacity component.
 * Format: OK|affectedCount  or  ERR|message
 */
function setOverlayOpacity(opacity) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) { return "ERR|Нет активной секвенции"; }
        var val = parseFloat(opacity);
        if (isNaN(val)) { return "ERR|Некорректная непрозрачность"; }
        if (val < 0) { val = 0; }
        if (val > 100) { val = 100; }

        var affected = 0;
        var n = seq.videoTracks.numTracks;
        for (var t = 0; t < n; t++) {
            var track = seq.videoTracks[t];
            for (var c = 0; c < track.clips.numItems; c++) {
                var clip = track.clips[c];
                if (_isARSSafezoneClip(clip)) {
                    if (_setClipOpacity(clip, val)) { affected++; }
                }
            }
        }
        if (affected === 0) { return "ERR|Не удалось изменить непрозрачность. Проверьте наложения и ключевые кадры."; }
        return "OK|" + affected;
    } catch (e) {
        return "ERR|" + e.toString();
    }
}

/**
 * Lists ARSSafezone overlays currently on the timeline.
 * Format: OK|name::Vtrack::startSec::endSec;;name::Vtrack::startSec::endSec
 *         OK|   (when none)
 */
function listOverlays() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) { return "OK|"; }
        var out = [];
        var n = seq.videoTracks.numTracks;
        for (var t = 0; t < n; t++) {
            var track = seq.videoTracks[t];
            for (var c = 0; c < track.clips.numItems; c++) {
                var clip = track.clips[c];
                if (_isARSSafezoneClip(clip)) {
                    var st = 0, en = 0;
                    try { st = clip.start.seconds; } catch (e1) {}
                    try { en = clip.end.seconds; } catch (e2) {}
                    out.push(_clean(clip.name) + "::V" + (t + 1) + "::" + _round2(st) + "::" + _round2(en));
                }
            }
        }
        return "OK|" + out.join(";;");
    } catch (e) {
        return "ERR|" + e.toString();
    }
}

/**
 * Deletes the "ARSSafezone Guides" bin (and its contents) from the project.
 * Any overlay clips on the timeline that reference those items are removed by Premiere too.
 * Format: OK|binsRemoved
 */
function deleteARSSafezoneBin() {
    try {
        if (!app.project) { return "ERR|Откройте проект"; }
        var root = app.project.rootItem;
        var removed = 0;
        for (var i = root.children.numItems - 1; i >= 0; i--) {
            var c = root.children[i];
            try {
                if (c && c.name === ARS_SAFEZONE_BIN && c.type === ProjectItemType.BIN) {
                    c.deleteBin();
                    removed++;
                }
            } catch (eDel) {}
        }
        return "OK|" + removed;
    } catch (e) {
        return "ERR|" + e.toString();
    }
}

/* -------------------------------------------------------------------------------------------- */
/* Internal helpers                                                                             */
/* -------------------------------------------------------------------------------------------- */

function _sequenceEndSeconds(seq) {
    try {
        if (seq.end !== undefined && seq.end !== null) {
            var ticks = parseFloat(String(seq.end));
            if (!isNaN(ticks) && ticks > 0) { return ticks / TICKS_PER_SECOND; }
        }
    } catch (e) {}
    return 0;
}

function _inPointSeconds(seq) {
    try { if (seq.getInPointAsTime) { return seq.getInPointAsTime().seconds; } } catch (e1) {}
    try { var v = parseFloat(seq.getInPoint()); if (!isNaN(v)) { return v; } } catch (e2) {}
    return 0;
}

function _outPointSeconds(seq) {
    try { if (seq.getOutPointAsTime) { return seq.getOutPointAsTime().seconds; } } catch (e1) {}
    try { var v = parseFloat(seq.getOutPoint()); if (!isNaN(v)) { return v; } } catch (e2) {}
    return 0;
}

function _isARSSafezoneClip(clip) {
    try {
        return clip && clip.name && (String(clip.name).indexOf(ARS_SAFEZONE_PREFIX) === 0);
    } catch (e) { return false; }
}

function _removeOverlayClips(seq) {
    var removed = 0;
    var n = seq.videoTracks.numTracks;
    for (var t = 0; t < n; t++) {
        var track = seq.videoTracks[t];
        for (var c = track.clips.numItems - 1; c >= 0; c--) {
            var clip = track.clips[c];
            if (_isARSSafezoneClip(clip)) {
                try { clip.remove(false, false); removed++; } catch (e) {}
            }
        }
    }
    return removed;
}

/**
 * Returns the index of the topmost video track that already holds a ARSSafezone
 * overlay clip, or -1 if none exists.
 */
function _findARSSafezoneTrackIndex(seq) {
    var n = seq.videoTracks.numTracks;
    for (var t = n - 1; t >= 0; t--) {
        var track = seq.videoTracks[t];
        for (var c = 0; c < track.clips.numItems; c++) {
            if (_isARSSafezoneClip(track.clips[c])) { return t; }
        }
    }
    return -1;
}

/**
 * If the topmost video track is empty, returns its index (reuse it).
 * Otherwise adds a new video track on top and returns the new top index.
 */
function _resolveEmptyTopOrNewTrack(seq) {
    var n = seq.videoTracks.numTracks;
    if (n > 0) {
        var top = seq.videoTracks[n - 1];
        try { if (top && top.clips && top.clips.numItems === 0) { return n - 1; } } catch (e) {}
    }
    return _addTopTrack(seq);
}

function _trackOnlyHasARS(track) {
    try {
        if (track.isLocked && track.isLocked()) { return false; }
        for (var i = 0; i < track.clips.numItems; i++) {
            if (!_isARSSafezoneClip(track.clips[i])) { return false; }
        }
        return true;
    } catch (e) { return false; }
}

/**
 * Adds a single empty video track at the top of the sequence and returns its index.
 */
function _addTopTrack(seq) {
    var before = seq.videoTracks.numTracks;
    try {
        app.enableQE();
        var qeSeq = qe.project.getActiveSequence();
        if (qeSeq) {
            try {
                // addTracks(numVideo, videoTrackIndex, numAudio, audioTrackIndex)
                qeSeq.addTracks(1, before, 0, 0);
            } catch (e1) {
                try { qeSeq.addTracks(1, 0, 0, 0); } catch (e2) {}
            }
        }
    } catch (eQE) {}

    var after = seq.videoTracks.numTracks;
    if (after <= before) { throw new Error("Не удалось создать видеодорожку. Добавьте пустую дорожку сверху и повторите."); }
    return after - 1;
}

function _getARSSafezoneBin() {
    var root = app.project.rootItem;
    for (var i = 0; i < root.children.numItems; i++) {
        var c = root.children[i];
        try {
            if (c.name === ARS_SAFEZONE_BIN && c.type === ProjectItemType.BIN) { return c; }
        } catch (e) {}
    }
    try { return root.createBin(ARS_SAFEZONE_BIN); } catch (e2) { return root; }
}

function _findProjectItemByName(parent, name) {
    if (!parent || !parent.children) { return null; }
    for (var i = 0; i < parent.children.numItems; i++) {
        var c = parent.children[i];
        try {
            if (c.type === ProjectItemType.BIN) {
                var r = _findProjectItemByName(c, name);
                if (r) { return r; }
            } else if (c.name === name) {
                return c;
            }
        } catch (e) {}
    }
    return null;
}

// Built-in component matchName is language independent. ComponentParam does not
// consistently expose matchName in CEP, so accept both supported display names.
function _opacityParam(clip) {
    try {
        var comps = clip.components;
        for (var i = 0; i < comps.numItems; i++) {
            var comp = comps[i], match = "", name = "";
            try { match = String(comp.matchName); } catch (e1) {}
            try { name = String(comp.displayName); } catch (e2) {}
            if (match !== "AE.ADBE Opacity" && match !== "ADBE Opacity" &&
                name !== "Opacity" && name !== "Непрозрачность") { continue; }
            var props = comp.properties;
            for (var j = 0; j < props.numItems; j++) {
                var p = props[j], pn = "", pm = "";
                try { pn = String(p.displayName); } catch (e3) {}
                try { pm = String(p.matchName); } catch (e4) {}
                if (pm === "ADBE Opacity" || pm === "AE.ADBE Opacity-0001" ||
                    pn === "Opacity" || pn === "Непрозрачность") { return p; }
            }
        }
    } catch (e) {}
    return null;
}
function _setClipOpacity(clip, val) {
    var p = _opacityParam(clip);
    if (!p) { return false; }
    try {
        // Preserve animation created by the editor rather than discarding keys.
        if (p.isTimeVarying && p.isTimeVarying()) { return false; }
        p.setValue(val, true);
        var actual = Number(p.getValue());
        return isFinite(actual) && Math.abs(actual - val) < 0.1;
    } catch (e) { return false; }
}

function _baseName(path) {
    var p = String(path).replace(/\\/g, "/");
    var parts = p.split("/");
    return parts[parts.length - 1];
}

function _round2(num) {
    return Math.round(parseFloat(num) * 100) / 100;
}

function _clean(s) {
    // Strip the field/record separators so parsing on the panel side stays reliable.
    return String(s).replace(/\|/g, " ").replace(/::/g, " ").replace(/;;/g, " ");
}
