#!/bin/bash
set -euo pipefail
TARGET="$HOME/Library/Application Support/Adobe/CEP/extensions/ARS_SAFEZONE"
DATA="$HOME/Library/Application Support/ARS_SAFEZONE/installation-backups"
echo 'ARS SAFEZONE — удаление панели. Закройте Premiere Pro.'
if pgrep -f '/Adobe Premiere Pro[^/]*/Adobe Premiere Pro.*Contents/MacOS/' >/dev/null 2>&1; then echo 'Сначала закройте Premiere.'; exit 1; fi
if [[ -f "$TARGET/CSXS/manifest.xml" ]] && grep -q 'com.ars.safezone.cep' "$TARGET/CSXS/manifest.xml"; then
 read -r -p 'Убрать панель из Premiere? Пресеты и PNG сохранятся. [y/N] ' ANSWER
 if [[ "$ANSWER" = y || "$ANSWER" = Y ]]; then
  mkdir -p "$DATA"
  mv "$TARGET" "$DATA/removed-$(date +%Y%m%d-%H%M%S)-$$"
  echo 'Панель убрана. Пресеты, PNG и резервная копия сохранены.'
 fi
else echo 'Установленная панель ARS SAFEZONE не найдена.'; fi
read -r -p 'Нажмите Enter для выхода…' || true
