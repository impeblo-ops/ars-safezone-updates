(function () {
    'use strict';

    function bytes(base64) {
        var binary = atob(base64);
        return Uint8Array.from(binary, function (c) { return c.charCodeAt(0); });
    }

    function https(value) {
        if (typeof value !== 'string' || /[\s\\]/.test(value)) return false;
        try {
            var url = new URL(value);
            return url.protocol === 'https:' && !!url.hostname && !url.username && !url.password;
        } catch (err) { return false; }
    }

    function read(url) {
        return new Promise(function (resolve, reject) {
            var xhr = new XMLHttpRequest();
            var address = new URL(url);
            address.searchParams.set('check', Date.now());
            xhr.open('GET', address.href, true);
            if (address.hostname === 'api.github.com') xhr.setRequestHeader('Accept', 'application/vnd.github.raw+json');
            xhr.timeout = 6500;
            xhr.onerror = xhr.onabort = xhr.ontimeout = function () { reject(Error('Ошибка сети')); };
            xhr.onprogress = function (event) { if (event.loaded > 65536) xhr.abort(); };
            xhr.onload = function () {
                try {
                    if (xhr.status !== 200 || xhr.responseText.length > 65536) throw Error('Ошибка ответа');
                    resolve(JSON.parse(xhr.responseText));
                } catch (err) { reject(err); }
            };
            xhr.send();
        });
    }

    async function check(config, os) {
        var urls = (config.manifests || []).filter(https);
        if (!urls.length) throw Error('Источники обновлений не настроены.');
        var algorithm = {name:'RSASSA-PKCS1-v1_5', hash:'SHA-256'};
        var key = await window.crypto.subtle.importKey('spki', bytes(config.publicKey), algorithm, false, ['verify']);
        for (var i = 0; i < urls.length; i++) {
            try {
                var envelope = await read(urls[i]);
                var payload = bytes(envelope.payload);
                if (!await window.crypto.subtle.verify(algorithm, key, bytes(envelope.signature), payload)) continue;
                var data = JSON.parse(new TextDecoder('utf-8').decode(payload));
                if (data.product !== 'ARS SAFEZONE' || !/^\d+\.\d+\.\d+$/.test(data.version)) continue;
                var asset = data.downloads[os];
                if (!/^[a-f0-9]{64}$/.test(asset.sha256) || !Array.isArray(asset.urls) ||
                    !asset.urls.length || !asset.urls.every(https)) continue;
                var links = asset.urls.slice();
                if (i > 0 && links.length > 1) links.unshift(links.splice(1, 1)[0]);
                return {envelope:envelope,version:data.version, notes:String(data.notes || '').slice(0, 4000),
                    url:links[0], urls:links, sha256:asset.sha256};
            } catch (err) { /* Try the mirror after a network, format or signature error. */ }
        }
        throw Error('Не удалось получить проверенное обновление. Попробуйте позже.');
    }

    window.ARSUpdateFeed = {check:check, https:https};
})();
