/**************************************************************************************************
 *
 * CSInterface - v9.4.0 (compatible with CEP 9, 10, 11, 12)
 *
 * A bundled, self-contained CEP interface library. No external/CDN dependency.
 * Based on Adobe's public CEP CSInterface specification.
 *
 **************************************************************************************************/

/** Stores constants for the window types. */
function CSXSWindowType() {}
CSXSWindowType._PANEL = "Panel";
CSXSWindowType._MODELESS = "Modeless";
CSXSWindowType._MODAL_DIALOG = "ModalDialog";

/** EvalScript error message */
var EvalScript_ErrMessage = "EvalScript error.";

/** @class Version - represents a CEP version with major/minor/micro/special parts. */
function Version(major, minor, micro, special) {
    this.major = major;
    this.minor = minor;
    this.micro = micro;
    this.special = special;
}
Version.MAX_NUM = 999999999;

/** @class VersionBound */
function VersionBound(version, inclusive) {
    this.version = version;
    this.inclusive = inclusive;
}

/** @class VersionRange */
function VersionRange(lowerBound, upperBound) {
    this.lowerBound = lowerBound;
    this.upperBound = upperBound;
}

/** @class Runtime - stores name & version-range of a runtime. */
function Runtime(name, versionRange) {
    this.name = name;
    this.versionRange = versionRange;
}

/** @class Extension - stores info about an extension. */
function Extension(id, name, mainPath, basePath, windowType, width, height,
    minWidth, minHeight, maxWidth, maxHeight,
    defaultExtensionDataXml, specialExtensionDataXml,
    requiredRuntimeList, isAutoVisible, isPluginExtension) {
    this.id = id;
    this.name = name;
    this.mainPath = mainPath;
    this.basePath = basePath;
    this.windowType = windowType;
    this.width = width;
    this.height = height;
    this.minWidth = minWidth;
    this.minHeight = minHeight;
    this.maxWidth = maxWidth;
    this.maxHeight = maxHeight;
    this.defaultExtensionDataXml = defaultExtensionDataXml;
    this.specialExtensionDataXml = specialExtensionDataXml;
    this.requiredRuntimeList = requiredRuntimeList;
    this.isAutoVisible = isAutoVisible;
    this.isPluginExtension = isPluginExtension;
}

/** @class CSEvent - a standard CEP event. */
function CSEvent(type, scope, appId, extensionId) {
    this.type = type;
    this.scope = scope;
    this.appId = appId;
    this.extensionId = extensionId;
    this.data = "";
}

/** @class SystemPath - stores operating-system-specific location constants. */
function SystemPath() {}
SystemPath.USER_DATA = "userData";
SystemPath.COMMON_FILES = "commonFiles";
SystemPath.MY_DOCUMENTS = "myDocuments";
SystemPath.APPLICATION = "application";
SystemPath.EXTENSION = "extension";
SystemPath.HOST_APPLICATION = "hostApplication";

/** @class ColorType */
function ColorType() {}
ColorType.RGB = "rgb";
ColorType.GRADIENT = "gradient";
ColorType.NONE = "none";

/** @class RGBColor */
function RGBColor(red, green, blue, alpha) {
    this.red = red;
    this.green = green;
    this.blue = blue;
    this.alpha = alpha;
}

/** @class Color */
function Color(type, antialiasLevel, color) {
    this.type = type;
    this.antialiasLevel = antialiasLevel;
    this.color = color;
}

/** @class AppSkinInfo */
function AppSkinInfo(baseFontFamily, baseFontSize, appBarBackgroundColor,
    panelBackgroundColor, appBarBackgroundColorSRGB,
    panelBackgroundColorSRGB, systemHighlightColor) {
    this.baseFontFamily = baseFontFamily;
    this.baseFontSize = baseFontSize;
    this.appBarBackgroundColor = appBarBackgroundColor;
    this.panelBackgroundColor = panelBackgroundColor;
    this.appBarBackgroundColorSRGB = appBarBackgroundColorSRGB;
    this.panelBackgroundColorSRGB = panelBackgroundColorSRGB;
    this.systemHighlightColor = systemHighlightColor;
}

/** @class HostEnvironment */
function HostEnvironment(appName, appVersion, appLocale, appUILocale, appId,
    isAppOnline, appSkinInfo) {
    this.appName = appName;
    this.appVersion = appVersion;
    this.appLocale = appLocale;
    this.appUILocale = appUILocale;
    this.appId = appId;
    this.isAppOnline = isAppOnline;
    this.appSkinInfo = appSkinInfo;
}

/** @class HostCapabilities */
function HostCapabilities(EXTENDED_PANEL_MENU, EXTENDED_PANEL_ICONS,
    DELEGATE_APE_ENGINE, SUPPORT_HTML_EXTENSIONS, DISABLE_FLASH_EXTENSIONS) {
    this.EXTENDED_PANEL_MENU = EXTENDED_PANEL_MENU;
    this.EXTENDED_PANEL_ICONS = EXTENDED_PANEL_ICONS;
    this.DELEGATE_APE_ENGINE = DELEGATE_APE_ENGINE;
    this.SUPPORT_HTML_EXTENSIONS = SUPPORT_HTML_EXTENSIONS;
    this.DISABLE_FLASH_EXTENSIONS = DISABLE_FLASH_EXTENSIONS;
}

/** @class ApiVersion */
function ApiVersion(major, minor, micro) {
    this.major = major;
    this.minor = minor;
    this.micro = micro;
}

/** @class MenuItemStatus */
function MenuItemStatus(menuItemLabel, enabled, checked) {
    this.menuItemLabel = menuItemLabel;
    this.enabled = enabled;
    this.checked = checked;
}

/** @class ContextMenuItemStatus */
function ContextMenuItemStatus(menuItemID, enabled, checked) {
    this.menuItemID = menuItemID;
    this.enabled = enabled;
    this.checked = checked;
}

/**
 * @class CSInterface
 * The main interface for communication with the host application.
 */
function CSInterface() {
    this.hostEnvironment = (typeof window.__adobe_cep__ !== "undefined")
        ? this.getHostEnvironment()
        : null;
}

CSInterface.THEME_COLOR_CHANGED_EVENT = "com.adobe.csxs.events.ThemeColorChanged";

/** Retrieves information about the host environment in which the panel is running. */
CSInterface.prototype.getHostEnvironment = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return null; }
    this.hostEnvironment = JSON.parse(window.__adobe_cep__.getHostEnvironment());
    return this.hostEnvironment;
};

/** Closes this extension. */
CSInterface.prototype.closeExtension = function() {
    if (typeof window.__adobe_cep__ !== "undefined") {
        window.__adobe_cep__.closeExtension();
    }
};

/** Retrieves a path for which a constant is defined in the system. */
CSInterface.prototype.getSystemPath = function(pathType) {
    if (typeof window.__adobe_cep__ === "undefined") { return ""; }
    var path = decodeURI(window.__adobe_cep__.getSystemPath(pathType));
    var OSVersion = this.getOSInformation();
    if (OSVersion.indexOf("Windows") >= 0) {
        path = path.replace("file:///", "");
    } else if (OSVersion.indexOf("Mac") >= 0) {
        path = path.replace("file://", "");
    }
    return path;
};

/** Evaluates a JavaScript script (ExtendScript) in the host application. */
CSInterface.prototype.evalScript = function(script, callback) {
    if (typeof window.__adobe_cep__ === "undefined") {
        if (callback) { callback(EvalScript_ErrMessage); }
        return;
    }
    if (callback === null || callback === undefined) {
        callback = function(result) {};
    }
    window.__adobe_cep__.evalScript(script, callback);
};

/** Retrieves the unique identifier of the host application. */
CSInterface.prototype.getApplicationID = function() {
    return this.hostEnvironment ? this.hostEnvironment.appId : "";
};

/** Retrieves host capability information for the current host application. */
CSInterface.prototype.getHostCapabilities = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return null; }
    return JSON.parse(window.__adobe_cep__.getHostCapabilities());
};

/** Triggers a CEP event programmatically. */
CSInterface.prototype.dispatchEvent = function(event) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    if (typeof event.data === "object") {
        event.data = JSON.stringify(event.data);
    }
    window.__adobe_cep__.dispatchEvent(event);
};

/** Registers an interest in a CEP event of a particular type. */
CSInterface.prototype.addEventListener = function(type, listener, obj) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    window.__adobe_cep__.addEventListener(type, listener, obj);
};

/** Removes a registered event listener. */
CSInterface.prototype.removeEventListener = function(type, listener, obj) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    window.__adobe_cep__.removeEventListener(type, listener, obj);
};

/** Loads and launches another extension. */
CSInterface.prototype.requestOpenExtension = function(extensionId, params) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    window.__adobe_cep__.requestOpenExtension(extensionId, params);
};

/** Retrieves the list of extensions currently loaded. */
CSInterface.prototype.getExtensions = function(extensionIds) {
    if (typeof window.__adobe_cep__ === "undefined") { return []; }
    var extensionIdsStr = JSON.stringify(extensionIds);
    var extensionsStr = window.__adobe_cep__.getExtensions(extensionIdsStr);
    return JSON.parse(extensionsStr);
};

/** Retrieves network-related preferences. */
CSInterface.prototype.getNetworkPreferences = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return null; }
    return JSON.parse(window.__adobe_cep__.getNetworkPreferences());
};

/** Initializes the resource bundle for this extension. */
CSInterface.prototype.initResourceBundle = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return null; }
    var resourceBundle = JSON.parse(window.__adobe_cep__.initResourceBundle());
    var resElms = document.querySelectorAll("[data-locale]");
    for (var n = 0; n < resElms.length; n++) {
        var resEl = resElms[n];
        var resKey = resEl.getAttribute("data-locale");
        if (resKey) {
            for (var key in resourceBundle) {
                if (key.indexOf(resKey) === 0) {
                    var resValue = resourceBundle[key];
                    if (resEl.innerHTML !== undefined) { resEl.innerHTML = resValue; }
                }
            }
        }
    }
    return resourceBundle;
};

/** Writes installation information to a file. */
CSInterface.prototype.dumpInstallationInfo = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return ""; }
    return window.__adobe_cep__.dumpInstallationInfo();
};

/** Retrieves the OS information. */
CSInterface.prototype.getOSInformation = function() {
    var userAgent = navigator.userAgent;
    if ((navigator.platform === "Win32") || (navigator.platform === "Windows")) {
        var winVersion = "Windows";
        if (userAgent.indexOf("Windows NT 5.0") > -1) winVersion += " 2000";
        else if (userAgent.indexOf("Windows NT 5.1") > -1) winVersion += " XP";
        else if (userAgent.indexOf("Windows NT 6.0") > -1) winVersion += " Vista";
        else if (userAgent.indexOf("Windows NT 6.1") > -1) winVersion += " 7";
        else if (userAgent.indexOf("Windows NT 6.2") > -1) winVersion += " 8";
        else if (userAgent.indexOf("Windows NT 6.3") > -1) winVersion += " 8.1";
        else if (userAgent.indexOf("Windows NT 10") > -1) winVersion += " 10";
        var bitStr = (userAgent.indexOf("WOW64") > -1 || userAgent.indexOf("Win64") > -1) ? " 64-bit" : " 32-bit";
        return winVersion + bitStr;
    } else if ((navigator.platform === "MacIntel") || (navigator.platform === "Macintosh")) {
        var result = "Mac OS X";
        var m = userAgent.match(/Mac OS X (10[\.\_\d]+)/);
        if (m && m[1]) { result += " " + m[1]; }
        return result;
    }
    return "Unknown Operation System";
};

/** Opens a URL in the default system browser. */
CSInterface.prototype.openURLInDefaultBrowser = function(url) {
    if (typeof cep !== "undefined" && cep.util) {
        return cep.util.openURLInDefaultBrowser(url);
    }
    return null;
};

/** Retrieves extension ID. */
CSInterface.prototype.getExtensionID = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return ""; }
    return window.__adobe_cep__.getExtensionId();
};

/** Retrieves the scale factor of the screen. */
CSInterface.prototype.getScaleFactor = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return 1; }
    return window.__adobe_cep__.getScaleFactor();
};

/** Sets a handler for scale-factor changes (macOS HiDPI). */
CSInterface.prototype.setScaleFactorChangedHandler = function(handler) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    window.__adobe_cep__.setScaleFactorChangedHandler(handler);
};

/** Retrieves the current CEP API version. */
CSInterface.prototype.getCurrentApiVersion = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return new ApiVersion(0, 0, 0); }
    var apiVersion = JSON.parse(window.__adobe_cep__.getCurrentApiVersion());
    return apiVersion;
};

/** Sets the title of the panel flyout menu. */
CSInterface.prototype.setPanelFlyoutMenu = function(menu) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    window.__adobe_cep__.invokeSync("setPanelFlyoutMenu", menu);
};

/** Updates a flyout menu item. */
CSInterface.prototype.updatePanelMenuItem = function(menuItemLabel, enabled, checked) {
    if (typeof window.__adobe_cep__ === "undefined") { return false; }
    var ret = false;
    if (this.getHostCapabilities().EXTENDED_PANEL_MENU) {
        var itemStatus = new MenuItemStatus(menuItemLabel, enabled, checked);
        ret = window.__adobe_cep__.invokeSync("updatePanelMenuItem", JSON.stringify(itemStatus));
    }
    return ret;
};

/** Sets a context menu via XML. */
CSInterface.prototype.setContextMenu = function(menu, callback) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    window.__adobe_cep__.invokeAsync("setContextMenu", menu, callback);
};

/** Sets a context menu via JSON. */
CSInterface.prototype.setContextMenuByJSON = function(menu, callback) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    window.__adobe_cep__.invokeAsync("setContextMenuByJSON", menu, callback);
};

/** Updates a context menu item. */
CSInterface.prototype.updateContextMenuItem = function(menuItemID, enabled, checked) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    var itemStatus = new ContextMenuItemStatus(menuItemID, enabled, checked);
    window.__adobe_cep__.invokeSync("updateContextMenuItem", JSON.stringify(itemStatus));
};

/** Gets the visibility state of the extension window. */
CSInterface.prototype.isWindowVisible = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return true; }
    return window.__adobe_cep__.invokeSync("isWindowVisible", "");
};

/** Resizes the extension content. */
CSInterface.prototype.resizeContent = function(width, height) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    window.__adobe_cep__.resizeContent(width, height);
};

/** Registers an invalid-certificate callback. */
CSInterface.prototype.registerInvalidCertificateCallback = function(callback) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    return window.__adobe_cep__.registerInvalidCertificateCallback(callback);
};

/** Registers a key-events-interest callback. */
CSInterface.prototype.registerKeyEventsInterest = function(keyEventsInterest) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    return window.__adobe_cep__.registerKeyEventsInterest(keyEventsInterest);
};

/** Sets the window title. */
CSInterface.prototype.setWindowTitle = function(title) {
    if (typeof window.__adobe_cep__ === "undefined") { return; }
    window.__adobe_cep__.invokeSync("setWindowTitle", title);
};

/** Gets the window title. */
CSInterface.prototype.getWindowTitle = function() {
    if (typeof window.__adobe_cep__ === "undefined") { return ""; }
    return window.__adobe_cep__.invokeSync("getWindowTitle", "");
};
