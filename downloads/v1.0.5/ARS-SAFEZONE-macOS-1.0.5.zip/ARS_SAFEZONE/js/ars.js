(function () {
    'use strict';
    var VERSION='1.0.5', cs=new CSInterface(), config={};
    function folder() {
        var p=cs.getSystemPath(SystemPath.USER_DATA)+'/ARS_SAFEZONE';
        var st=window.cep.fs.stat(p);
        if(st.err!==0)window.cep.fs.makedir(p);
        return p;
    }
    function readData(name) {
        try { var r=window.cep.fs.readFile(folder()+'/'+name); return r.err===0?JSON.parse(r.data):null; } catch(e){ return null; }
    }
    function writeData(name,data) {
        try { return window.cep.fs.writeFile(folder()+'/'+name,JSON.stringify(data)).err===0; } catch(e){ return false; }
    }
    function mix(c,target,t) {return 'rgb('+['red','green','blue'].map(function(k){return Math.round(c[k]+(target-c[k])*t);}).join(',')+')';}
    function theme() {
        var color=null;
        try {var env=cs.getHostEnvironment(),skin=env&&env.appSkinInfo;var bg=skin&&(skin.panelBackgroundColorSRGB||skin.panelBackgroundColor||skin.appBarBackgroundColor);color=bg&&bg.color;}catch(e){}
        if(!color||!isFinite(color.red)||!isFinite(color.green)||!isFinite(color.blue)){
            var light=window.matchMedia&&window.matchMedia('(prefers-color-scheme: light)').matches;
            color=light?{red:232,green:232,blue:232}:{red:30,green:30,blue:30};
        }
        var isLight=color.red*.2126+color.green*.7152+color.blue*.0722>155;
        var root=document.documentElement,st=root.style;
        root.setAttribute('data-ars-theme',isLight?'light':'dark');
        var palette={
            '--bg':mix(color,0,0),'--bg-raised':mix(color,255,isLight?.45:.045),
            '--bg-sunken':mix(color,isLight?255:0,isLight?.7:.18),
            '--panel':mix(color,isLight?0:255,isLight?.08:.10),
            '--border':mix(color,isLight?0:255,isLight?.19:.12),
            '--border-soft':mix(color,isLight?0:255,isLight?.10:.07),
            '--text':isLight?'#222621':'#eceee9','--text-dim':isLight?'#52594e':'#b1b6ac',
            '--text-faint':isLight?'#697063':'#899080',
            '--track':mix(color,isLight?0:255,isLight?.27:.20),
            '--checker':mix(color,isLight?0:255,isLight?.07:.055)
        };
        Object.keys(palette).forEach(function(k){st.setProperty(k,palette[k]);});
    }
    function validVersion(v){return typeof v==='string'&&/^\d+\.\d+\.\d+$/.test(v);}
    function newer(a,b){if(!validVersion(a)||!validVersion(b))return false;var x=a.split('.'),y=b.split('.');for(var i=0;i<3;i++){if(+x[i]!==+y[i])return +x[i]>+y[i];}return false;}
    var httpsURL = window.ARSUpdateFeed.https;
    function platform(){return /Mac/i.test(cs.getOSInformation()||navigator.platform)?'mac':'windows';}
    function check(callback) {
        window.ARSUpdateFeed.check(config, platform()).then(function (release) {
            var badge=document.getElementById('arsUpdates');
            badge.classList.toggle('ars-available',newer(release.version,VERSION));
            badge.textContent=newer(release.version,VERSION)?'Доступно обновление '+release.version:'Обновления · '+VERSION;
            badge.setAttribute('aria-live','polite');
            callback(null, release);
        }, function (err) { callback(err); });
    }
    function dialog(initial){
        if(document.querySelector('.ars-update-modal'))return;
        var ov=document.createElement('div');ov.className='s-modal-ov';
        var m=document.createElement('div');m.className='s-modal ars-update-modal';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','Обновления ARS SAFEZONE');
        m.innerHTML='<div class="s-modal-t">ARS SAFEZONE</div><div class="s-modal-sub">Версия '+VERSION+'</div><p class="ars-update-copy" role="status"></p><a class="ars-shop-link" href="https://arszona.ru/">Больше товаров на arszona.ru ↗</a><div class="s-modal-btns"><button class="btn btn-ghost" type="button">Закрыть</button><button class="btn btn-primary" type="button" hidden>Скачать обновление</button></div>';
        var text=m.querySelector('p'),close=m.querySelector('.btn-ghost'),download=m.querySelector('.btn-primary'),release=null;
        var shop=m.querySelector('.ars-shop-link');
        shop.onclick=function(e){e.preventDefault();cs.openURLInDefaultBrowser(shop.href);};
        var running=false,approved=false,jobPath='';
        function signal(name){if(window.cep.fs.writeFile(jobPath+'/'+name,'1').err!==0)throw Error('Не удалось записать состояние обновления.');}
        function evaluate(script){return new Promise(function(resolve){cs.evalScript(script,resolve);});}
        function delay(){return new Promise(function(resolve){setTimeout(resolve,350);});}
        async function automatic(){
            var io=window.cep.fs;
            var id=Array.from(crypto.getRandomValues(new Uint8Array(16)),function(n){return ('0'+n.toString(16)).slice(-2);}).join('');
            var root=folder(),jobs=root+'/update-requests';jobPath=jobs+'/'+id;
            if(io.stat(jobs).err!==0 && io.makedir(jobs).err!==0)throw Error('Не удалось создать папку обновлений.');
            var ticket={id:id,envelope:release.envelope};
            if(io.makedir(jobPath).err!==0 || io.writeFile(jobPath+'/job.json',JSON.stringify(ticket)).err!==0 || !writeData('update-job.json',ticket))throw Error('Не удалось подготовить обновление.');
            text.textContent='Скачиваю и проверяю установщик…';
            var launched=await evaluate('arsLaunchUpdateWorker()');
            if(launched!=='OK'){
                var helper=(cs.getSystemPath(SystemPath.EXTENSION)+'/Updater.exe').replace(/\//g,'\\');
                var proc=window.cep.process;
                if(!proc || proc.createProcess(helper,id).err!==0)throw Error('Windows не запустила помощник.');
            }
            var until=Date.now()+150000;
            while(io.stat(jobPath+'/ready').err!==0){
                if(!running)return;
                var issue=io.readFile(jobPath+'/error.txt');if(issue.err===0)throw Error(issue.data);
                if(Date.now()>until)throw Error('Установщик не подтвердил готовность. Проверьте подключение к GitHub.');
                await delay();
            }
            if(!running)return;
            text.textContent='Установщик готов. Сохраняю проекты…';
            var saved=await evaluate('arsSaveProjectsForUpdate()');
            if(!running)return;
            if(saved!=='OK' && saved!=='NATIVE')throw Error(saved && saved!=='EvalScript error.'?saved:'Premiere не подтвердил сохранение.');
            signal('approved');approved=true;
            text.textContent=saved==='NATIVE'?'Закрываю Premiere. Подтвердите сохранение, если Adobe покажет запрос.':'Проекты сохранены. Закрываю Premiere и устанавливаю обновление…';
            cs.evalScript('app.quit()',function(reply){if(reply==='EvalScript error.')text.textContent='Premiere не смог закрыться. Проверьте открытые окна программы.';});
            until=Date.now()+190000;
            while(document.body.contains(ov)){
                var failure=io.readFile(jobPath+'/error.txt');if(failure.err===0)throw Error(failure.data);
                if(Date.now()>until)throw Error('Premiere остался открыт. Завершите диалог Adobe и повторите обновление.');
                await delay();
            }
        }
        var previous=document.activeElement;
        function dismiss(){if(running && !approved && jobPath){try{signal('cancel');}catch(e){}}running=false;ov.remove();document.removeEventListener('keydown',keys);if(previous)previous.focus();}
        function keys(e){if(e.key==='Escape'){dismiss();}if(e.key==='Tab'){var buttons=m.querySelectorAll('a[href],button:not([hidden]):not(:disabled)');var first=buttons[0],last=buttons[buttons.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}}
        close.onclick=dismiss;ov.onclick=function(e){if(e.target===ov)dismiss();};
        download.onclick=function(){
            if(!release)return;
            if(platform()==='windows'){
                if(running)return;
                running=true;approved=false;download.disabled=true;
                automatic().catch(function(e){
                    if(jobPath){try{signal('cancel');}catch(ignored){}}
                    running=false;approved=false;download.disabled=false;text.classList.add('error');
                    text.textContent='Обновление остановлено. '+e.message;
                    if(!m.querySelector('.ars-manual')){
                        var manual=document.createElement('button');manual.className='btn btn-ghost ars-manual';manual.textContent='Скачать вручную';
                        manual.onclick=function(){cs.openURLInDefaultBrowser(release.url);};download.parentNode.insertBefore(manual,download);
                    }
                });return;
            }
            cs.openURLInDefaultBrowser(release.url);
        };
        ov.appendChild(m);document.body.appendChild(ov);document.addEventListener('keydown',keys);close.focus();
        function show(err,data,message){
            if(!document.body.contains(ov))return;
            if(err){text.classList.add('error');text.textContent=err.message;return;}
            if(message){text.textContent=message;return;}
            if(newer(data.version,VERSION)){release=data;text.textContent='Доступна версия '+data.version+'.\n'+data.notes+'\n\nПри обновлении Premiere потребуется закрыть.';download.hidden=false;
                if(platform()==='windows')download.textContent='Сохранить проекты и обновить';
                if(data.urls.length>1){
                    var mirror=document.createElement('button');
                    mirror.type='button';mirror.className='btn btn-ghost';mirror.textContent='Скачать с другого сервера';
                    mirror.onclick=function(){cs.openURLInDefaultBrowser(data.urls[1]);};
                    download.parentNode.insertBefore(mirror,download);
                }}
            else{text.textContent='У вас актуальная версия.';}
        }
        text.textContent='Проверяю обновления…';if(initial)show(null,initial);else check(show);
    }
    window.ARS={version:VERSION,readData:readData,writeData:writeData,theme:theme,newer:newer,httpsURL:httpsURL};
    theme();cs.addEventListener(CSInterface.THEME_COLOR_CHANGED_EVENT,theme);
    if(window.matchMedia){var mq=window.matchMedia('(prefers-color-scheme: light)');if(mq.addListener)mq.addListener(theme);}
    function init(){
        try{var r=window.cep.fs.readFile(cs.getSystemPath(SystemPath.EXTENSION)+'/updates.json');if(r.err===0)config=JSON.parse(r.data);}catch(e){}
        document.getElementById('arsUpdates').onclick=function(){dialog();};
        
        if(config.manifests && config.manifests.length){
            var lastCheck=0,announced='';
            function onOpen(){
                if(document.hidden || Date.now()-lastCheck<45000)return;
                lastCheck=Date.now();check(function(err,data){
                    if(!err && newer(data.version,VERSION) && announced!==data.version){
                        announced=data.version;dialog(data);
                    }
                });
            }
            document.addEventListener('visibilitychange',onOpen);window.addEventListener('focus',onOpen);setTimeout(onOpen,200);
        }
    }
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
