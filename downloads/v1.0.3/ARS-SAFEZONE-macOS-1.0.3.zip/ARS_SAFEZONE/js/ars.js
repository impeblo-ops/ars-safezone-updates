(function () {
    'use strict';
    var VERSION='1.0.3', cs=new CSInterface(), config={};
    function folder() {
        var p=cs.getSystemPath(SystemPath.USER_DATA)+'/ARS_SAFEZONE';
        var st=window.cep.fs.stat(p);
        if(st.err!==0)window.cep.fs.makedir(p);
        return p;
    }
    function readData(name) {
        try { var r=window.cep.fs.readFile(folder()+'/'+name); return r.err===0?JSON.parse(r.data):null; } catch(e){ return null; }
    }
    function writeData(name,data) {
        try { return window.cep.fs.writeFile(folder()+'/'+name,JSON.stringify(data)).err===0; } catch(e){ return false; }
    }
    function mix(c,target,t) {return 'rgb('+['red','green','blue'].map(function(k){return Math.round(c[k]+(target-c[k])*t);}).join(',')+')';}
    function theme() {
        var color=null;
        try {var env=cs.getHostEnvironment(),skin=env&&env.appSkinInfo;var bg=skin&&(skin.panelBackgroundColorSRGB||skin.panelBackgroundColor||skin.appBarBackgroundColor);color=bg&&bg.color;}catch(e){}
        if(!color||!isFinite(color.red)||!isFinite(color.green)||!isFinite(color.blue)){
            var light=window.matchMedia&&window.matchMedia('(prefers-color-scheme: light)').matches;
            color=light?{red:232,green:232,blue:232}:{red:30,green:30,blue:30};
        }
        var isLight=color.red*.2126+color.green*.7152+color.blue*.0722>155;
        var root=document.documentElement,st=root.style;
        root.setAttribute('data-ars-theme',isLight?'light':'dark');
        var palette={
            '--bg':mix(color,0,0),'--bg-raised':mix(color,255,isLight?.45:.045),
            '--bg-sunken':mix(color,isLight?255:0,isLight?.7:.18),
            '--panel':mix(color,isLight?0:255,isLight?.08:.10),
            '--border':mix(color,isLight?0:255,isLight?.19:.12),
            '--border-soft':mix(color,isLight?0:255,isLight?.10:.07),
            '--text':isLight?'#222621':'#eceee9','--text-dim':isLight?'#52594e':'#b1b6ac',
            '--text-faint':isLight?'#697063':'#899080',
            '--track':mix(color,isLight?0:255,isLight?.27:.20),
            '--checker':mix(color,isLight?0:255,isLight?.07:.055)
        };
        Object.keys(palette).forEach(function(k){st.setProperty(k,palette[k]);});
    }
    function validVersion(v){return typeof v==='string'&&/^\d+\.\d+\.\d+$/.test(v);}
    function newer(a,b){if(!validVersion(a)||!validVersion(b))return false;var x=a.split('.'),y=b.split('.');for(var i=0;i<3;i++){if(+x[i]!==+y[i])return +x[i]>+y[i];}return false;}
    var httpsURL = window.ARSUpdateFeed.https;
    function platform(){return /Mac/i.test(cs.getOSInformation()||navigator.platform)?'mac':'windows';}
    function check(callback) {
        window.ARSUpdateFeed.check(config, platform()).then(function (release) {
            callback(null, release);
        }, function (err) { callback(err); });
    }
    function dialog(initial){
        if(document.querySelector('.ars-update-modal'))return;
        var ov=document.createElement('div');ov.className='s-modal-ov';
        var m=document.createElement('div');m.className='s-modal ars-update-modal';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','Обновления ARS SAFEZONE');
        m.innerHTML='<div class="s-modal-t">ARS SAFEZONE</div><div class="s-modal-sub">Версия '+VERSION+'</div><p class="ars-update-copy" role="status"></p><a class="ars-shop-link" href="https://arszona.ru/">Больше товаров на arszona.ru ↗</a><div class="s-modal-btns"><button class="btn btn-ghost" type="button">Закрыть</button><button class="btn btn-primary" type="button" hidden>Скачать обновление</button></div>';
        var text=m.querySelector('p'),close=m.querySelector('.btn-ghost'),download=m.querySelector('.btn-primary'),release=null;
        var shop=m.querySelector('.ars-shop-link');
        shop.onclick=function(e){e.preventDefault();cs.openURLInDefaultBrowser(shop.href);};
        var previous=document.activeElement;
        function dismiss(){ov.remove();document.removeEventListener('keydown',keys);if(previous)previous.focus();}
        function keys(e){if(e.key==='Escape'){dismiss();}if(e.key==='Tab'){var buttons=m.querySelectorAll('a[href],button:not([hidden]):not(:disabled)');var first=buttons[0],last=buttons[buttons.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}}
        close.onclick=dismiss;ov.onclick=function(e){if(e.target===ov)dismiss();};
        download.onclick=function(){
            if(!release)return;
            if(platform()==='windows' && window.cep.process) {
                download.disabled=true;
                text.textContent='Сохраняю открытые проекты Premiere…';
                cs.evalScript('arsSaveProjectsForUpdate()',function(result){
                    if(!document.body.contains(ov))return;
                    if(result!=='OK'){
                        text.textContent=(result && result!=='EvalScript error.')?result:'Premiere не подтвердил сохранение. Обновление остановлено.';
                        download.disabled=false;return;
                    }
                    try {
                        var helper=cs.getSystemPath(SystemPath.EXTENSION)+'/Updater.exe';
                        var args=[helper,release.sha256].concat(release.urls);
                        var started=window.cep.process.createProcess.apply(window.cep.process,args);
                        if(started.err===0){text.textContent='Проекты сохранены. Помощник проверит загрузку и закроет Premiere для установки.';return;}
                    }catch(e){}
                    text.textContent='Помощник не запустился. Открываю установщик в браузере.';
                    cs.openURLInDefaultBrowser(release.url); download.disabled=false;
                });
                return;
            }
            cs.openURLInDefaultBrowser(release.url);
        };
        ov.appendChild(m);document.body.appendChild(ov);document.addEventListener('keydown',keys);close.focus();
        function show(err,data,message){
            if(!document.body.contains(ov))return;
            if(err){text.classList.add('error');text.textContent=err.message;return;}
            if(message){text.textContent=message;return;}
            if(newer(data.version,VERSION)){release=data;text.textContent='Доступна версия '+data.version+'.\n'+data.notes+'\n\nПри обновлении Premiere потребуется закрыть.';download.hidden=false;
                if(platform()==='windows' && window.cep.process)download.textContent='Сохранить проекты и обновить';
                if(data.urls.length>1){
                    var mirror=document.createElement('button');
                    mirror.type='button';mirror.className='btn btn-ghost';mirror.textContent='Скачать с другого сервера';
                    mirror.onclick=function(){cs.openURLInDefaultBrowser(data.urls[1]);};
                    download.parentNode.insertBefore(mirror,download);
                }}
            else{text.textContent='У вас актуальная версия.';}
        }
        text.textContent='Проверяю обновления…';if(initial)show(null,initial);else check(show);
    }
    window.ARS={version:VERSION,readData:readData,writeData:writeData,theme:theme,newer:newer,httpsURL:httpsURL};
    theme();cs.addEventListener(CSInterface.THEME_COLOR_CHANGED_EVENT,theme);
    if(window.matchMedia){var mq=window.matchMedia('(prefers-color-scheme: light)');if(mq.addListener)mq.addListener(theme);}
    function init(){
        try{var r=window.cep.fs.readFile(cs.getSystemPath(SystemPath.EXTENSION)+'/updates.json');if(r.err===0)config=JSON.parse(r.data);}catch(e){}
        document.getElementById('arsUpdates').onclick=function(){dialog();};
        
        if(config.manifests && config.manifests.length){
            setTimeout(function(){check(function(err,data){if(err||!data)return;if(newer(data.version,VERSION))dialog(data);});},2000);
        }
    }
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
